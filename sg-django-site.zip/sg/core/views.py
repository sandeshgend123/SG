import json, urllib.request
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.db.models import Count, Sum
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .models import *
from .services import SERVICES, GOALS

def home(request):
    return render(request, "core/home.html", {"services": SERVICES.items(), "posts": BlogPost.objects.filter(published=True)[:3]})

def service(request, slug):
    s = SERVICES.get(slug) or (_ for _ in ()).throw(Http404())
    return render(request, "core/service.html", {"s": s, "cur": slug, "services": SERVICES.items()})

def blog(request):
    return render(request, "core/blog.html", {"posts": BlogPost.objects.filter(published=True)})

def post(request, slug):
    return render(request, "core/post.html", {"p": get_object_or_404(BlogPost, slug=slug, published=True)})

@require_POST
def contact(request):
    n, e = request.POST.get("name", "").strip()[:120], request.POST.get("email", "").strip()
    if n and "@" in e:
        m = request.POST.get("message", "")[:4000]
        Inquiry.objects.create(name=n, email=e, message=m)
        Lead.objects.create(name=n, email=e, source="Website")
    return redirect("/?sent=1#book")

def health(request):
    connection.ensure_connection()
    return JsonResponse({"status": "ok"})

# ---- AI features ----
def quote(request):
    base = SERVICES.get(request.GET.get("service"), (0, 0, 0, 30000))[3]
    size = {"starter": 1, "standard": 2, "enterprise": 3.5}.get(request.GET.get("size"), 1)
    extra = 15000 * ("admin" in request.GET) + 20000 * ("portal" in request.GET) + 12000 * ("chatbot" in request.GET)
    low = int(base * size + extra)
    return JsonResponse({"low": low, "high": int(low * 1.35), "currency": "INR"})

def recommend(request):
    g = request.GET.get("goal", "").lower()
    slug = next((v for k, v in GOALS.items() if k in g), "data-analytics")
    return JsonResponse({"slug": slug, "name": SERVICES[slug][0], "why": SERVICES[slug][1]})

SYSTEM = ("You are the website assistant for SG Analytics & Technologies, a Pune-based company offering Data Analytics, "
          "Business Intelligence, Python Development, AI & Automation, Website Development and Cloud Solutions. "
          "Answer briefly. Do not invent prices; point to the quotation calculator and the free consultation form.")

@require_POST
def chat(request):
    try: msg = json.loads(request.body)["message"][:500]
    except Exception: return JsonResponse({"reply": "Please send a message."}, status=400)
    n = request.session.get("chat_n", 0) + 1; request.session["chat_n"] = n
    if n > 30: return JsonResponse({"reply": "Chat limit reached. Please book a consultation."})
    if settings.ANTHROPIC_API_KEY:
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages", method="POST",
                data=json.dumps({"model": "claude-sonnet-4-6", "max_tokens": 300, "system": SYSTEM, "messages": [{"role": "user", "content": msg}]}).encode(),
                headers={"x-api-key": settings.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
            with urllib.request.urlopen(req, timeout=15) as r:
                return JsonResponse({"reply": json.load(r)["content"][0]["text"]})
        except Exception: pass
    low = msg.lower()
    for slug, s in SERVICES.items():
        if any(w in low for w in s[0].lower().replace("&", "").split()[:1]): return JsonResponse({"reply": f"{s[0]}: {s[1]}"})
    return JsonResponse({"reply": "Ask about our services or pricing, or book a free consultation below."})

# ---- Portals ----
def _client(request):
    c = Client.objects.filter(user=request.user).first()
    if not c: raise Http404("No client profile is linked to this login.")
    return c

@login_required
def portal(request):
    c = _client(request)
    if request.method == "POST" and request.POST.get("subject"):
        Ticket.objects.create(client=c, subject=request.POST["subject"][:160], message=request.POST.get("message", "")[:4000])
        return redirect("portal")
    return render(request, "core/portal.html", {"c": c, "projects": c.projects.prefetch_related("files", "invoices"), "tickets": c.tickets.all()})

@login_required
def download(request, kind, pk):
    c = _client(request)
    obj = get_object_or_404(ProjectFile if kind == "file" else Invoice, pk=pk, project__client=c)
    if not obj.file: raise Http404()
    return FileResponse(obj.file.open("rb"), as_attachment=True)

@staff_member_required
def staff(request):
    ctx = {"leads": Lead.objects.all()[:10], "stages": Lead.objects.values("stage").annotate(n=Count("id"), v=Sum("value")),
           "inq": Inquiry.objects.filter(handled=False)[:10], "tickets": Ticket.objects.exclude(status="closed")[:10],
           "projects": Project.objects.exclude(status="done")[:10]}
    return render(request, "core/staff.html", ctx)
