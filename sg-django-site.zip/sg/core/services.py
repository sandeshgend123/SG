SERVICES = {
 "data-analytics": ("Data Analytics", "Find patterns in your sales, operations and customer data.", ["Data cleaning and modelling in Python and SQL", "Exploratory analysis and forecasting", "Monthly insight reports"], 25000),
 "business-intelligence": ("Business Intelligence", "Live dashboards your whole team can read at a glance.", ["Power BI and Tableau dashboards", "Automated data refresh", "KPI definitions and team training"], 30000),
 "python-development": ("Python Development", "Custom software and scripts built around your process.", ["Django web applications and APIs", "Data pipelines and integrations", "Testing and documentation"], 40000),
 "ai-automation": ("AI & Automation", "Save hours on repetitive work and answer customers faster.", ["Chatbots and document processing", "Workflow automation", "Predictive models"], 45000),
 "website-development": ("Website Development", "Fast, mobile-first sites that rank and convert.", ["Responsive design and CMS", "SEO and speed optimisation", "Secure hosting over HTTPS"], 35000),
 "cloud-solutions": ("Cloud Solutions", "Reliable hosting, backups and monitoring.", ["Cloud migration and deployment", "Automated backups", "Uptime monitoring and access control"], 30000),
}
GOALS = {"analyse data": "data-analytics", "live reports": "business-intelligence", "automate": "ai-automation", "ai": "ai-automation", "website": "website-development", "cloud": "cloud-solutions", "software": "python-development"}
