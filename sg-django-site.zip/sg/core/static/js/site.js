const $=i=>document.getElementById(i);
function qs(o){return new URLSearchParams(o).toString()}
const fmt=n=>"₹"+n.toLocaleString("en-IN");
async function quote(){if(!$("qs"))return;const o={service:$("qs").value,size:$("qz").value};document.querySelectorAll(".ao:checked").forEach(c=>o[c.name]=1);
 const r=await (await fetch("/api/quote/?"+qs(o))).json();$("qe").textContent=fmt(r.low)+" – "+fmt(r.high)}
document.addEventListener("change",e=>{if(e.target.closest("#qcard"))quote()});quote();
if($("rg"))$("rg").onchange=async()=>{if(!$("rg").value)return;const r=await (await fetch("/api/recommend/?goal="+encodeURIComponent($("rg").value))).json();
 $("rr").innerHTML="<b>Recommended: "+r.name+"</b><p>"+r.why+"</p><a class='btn' href='/services/"+r.slug+"/'>See the service</a>"};
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;io.disconnect();e.target.querySelectorAll("[data-n]").forEach(el=>{const t=+el.dataset.n,s=el.dataset.s||"";let k=0;const id=setInterval(()=>{k=Math.min(t,k+Math.ceil(t/40));el.textContent=k+s;if(k>=t)clearInterval(id)},30)})}));
if($("stats"))io.observe($("stats"));
$("bb").onclick=()=>$("bp").classList.toggle("on");
function csrf(){return document.cookie.split("; ").find(c=>c.startsWith("csrftoken="))?.split("=")[1]||""}
$("bf").onsubmit=async e=>{e.preventDefault();const t=$("bi").value.trim();if(!t)return;const l=$("log");
 const u=document.createElement("p");u.className="u";u.textContent=t;l.appendChild(u);$("bi").value="";
 const b=document.createElement("p");b.textContent="…";l.appendChild(b);
 try{const r=await fetch("/api/chat/",{method:"POST",headers:{"X-CSRFToken":csrf(),"Content-Type":"application/json"},body:JSON.stringify({message:t})});b.textContent=(await r.json()).reply}catch(x){b.textContent="Sorry, something went wrong. Please use the consultation form."}
 l.scrollTop=l.scrollHeight};
