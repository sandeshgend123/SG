from django.contrib.auth import views as auth
from django.urls import path
from . import views as v
urlpatterns = [
    path("", v.home, name="home"), path("services/<slug:slug>/", v.service, name="service"),
    path("blog/", v.blog, name="blog"), path("blog/<slug:slug>/", v.post, name="post"),
    path("contact/", v.contact, name="contact"), path("health/", v.health),
    path("api/quote/", v.quote), path("api/recommend/", v.recommend), path("api/chat/", v.chat),
    path("login/", auth.LoginView.as_view(template_name="core/login.html"), name="login"),
    path("logout/", auth.LogoutView.as_view(), name="logout"),
    path("portal/", v.portal, name="portal"), path("portal/<str:kind>/<int:pk>/", v.download, name="download"),
    path("staff/", v.staff, name="staff"),
]
