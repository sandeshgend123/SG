from django.contrib import admin
from .models import *

@admin.register(Inquiry)
class InquiryA(admin.ModelAdmin):
    list_display = ("name", "email", "created", "handled"); list_filter = ("handled",); search_fields = ("name", "email", "message")
@admin.register(Lead)
class LeadA(admin.ModelAdmin):
    list_display = ("name", "source", "stage", "value", "created"); list_filter = ("stage", "source"); list_editable = ("stage",)
@admin.register(Client)
class ClientA(admin.ModelAdmin):
    list_display = ("name", "company", "email", "user"); search_fields = ("name", "company", "email")
class FileI(admin.TabularInline): model = ProjectFile; extra = 0
class InvI(admin.TabularInline): model = Invoice; extra = 0
@admin.register(Project)
class ProjectA(admin.ModelAdmin):
    list_display = ("title", "client", "status", "progress", "updated"); list_filter = ("status",); inlines = [FileI, InvI]
@admin.register(Ticket)
class TicketA(admin.ModelAdmin):
    list_display = ("subject", "client", "status", "created"); list_filter = ("status",)
@admin.register(BlogPost)
class BlogA(admin.ModelAdmin):
    list_display = ("title", "published", "created"); prepopulated_fields = {"slug": ("title",)}
