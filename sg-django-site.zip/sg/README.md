# SG Analytics & Technologies: Django site

## Run locally
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py setup_roles          # creates "Admin Staff" and "Support" roles
    python manage.py createsuperuser
    python manage.py runserver

## Use it
- Staff: /admin/ (leads, clients, projects, files, invoices, tickets, blog, inquiries) and /staff/ (summary).
- Clients: create a User (no staff status) and link it to a Client record; they log in at /login/ and use /portal/.
- Website form posts create an Inquiry and a Lead automatically.
- Client files and invoices are served only to the owning client (not via public /media/).

## AI chatbot
Set `ANTHROPIC_API_KEY` to enable AI answers; without it a simple keyword fallback is used.

## Production (HTTPS, security, backups, monitoring)
    export DJANGO_DEBUG=0 DJANGO_SECRET_KEY=... DJANGO_ALLOWED_HOSTS=yourdomain.com
    python manage.py collectstatic --noinput
    gunicorn sgsite.wsgi
- DEBUG=0 turns on HTTPS redirect, secure cookies, HSTS. Put it behind Nginx or a host with a TLS certificate (Let's Encrypt).
- Switch DATABASES to PostgreSQL for production.
- Backups: `python manage.py backup` (DB + uploads, keeps last 14). Cron: `0 2 * * * cd /path && python manage.py backup`. Copy zips off-server.
- Monitoring: point UptimeRobot or similar at `/health/`.
- Serve /media/ only through Django (already the case); do not expose the media folder in Nginx.

## Before launch
Replace placeholder stats, case studies and prices (core/services.py), add a real contact email, and add rate limiting (e.g. django-ratelimit) on /api/chat/ and /contact/.
