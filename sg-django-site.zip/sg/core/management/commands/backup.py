import shutil, datetime
from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Dump database + uploaded files into backups/<timestamp>.zip. Schedule daily with cron."
    def handle(self, *a, **o):
        d = settings.BASE_DIR / "backups"; d.mkdir(exist_ok=True)
        t = datetime.datetime.now().strftime("%Y%m%d-%H%M%S"); tmp = d / t; tmp.mkdir()
        with open(tmp / "data.json", "w") as f: call_command("dumpdata", "--natural-foreign", "--exclude=contenttypes", "--exclude=sessions", stdout=f)
        if settings.MEDIA_ROOT.exists(): shutil.copytree(settings.MEDIA_ROOT, tmp / "media")
        shutil.make_archive(str(d / t), "zip", tmp); shutil.rmtree(tmp)
        for old in sorted(d.glob("*.zip"))[:-14]: old.unlink()  # keep last 14
        self.stdout.write(f"Backup saved: backups/{t}.zip")
