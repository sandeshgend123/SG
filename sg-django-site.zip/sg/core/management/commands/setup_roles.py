from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Create role groups: Admin Staff (manage leads, clients, projects, blog, inquiries) and Support (tickets, inquiries only)."
    def handle(self, *a, **o):
        roles = {"Admin Staff": ["lead", "client", "project", "projectfile", "invoice", "ticket", "blogpost", "inquiry"],
                 "Support": ["ticket", "inquiry"]}
        for name, models in roles.items():
            g, _ = Group.objects.get_or_create(name=name)
            g.permissions.set(Permission.objects.filter(content_type__app_label="core", content_type__model__in=models))
        self.stdout.write("Roles ready. Add staff users to a group and tick 'Staff status'. Clients have no staff status.")
