from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static
admin.site.site_header = "SG Analytics & Technologies Admin"
urlpatterns = [path("admin/", admin.site.urls), path("", include("core.urls"))]
