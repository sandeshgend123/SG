from django.conf import settings
from django.db import models

U = settings.AUTH_USER_MODEL

class Inquiry(models.Model):
    name = models.CharField(max_length=120); email = models.EmailField()
    message = models.TextField(blank=True); created = models.DateTimeField(auto_now_add=True)
    handled = models.BooleanField(default=False)
    class Meta: ordering = ["-created"]; verbose_name_plural = "inquiries"
    def __str__(self): return f"{self.name} ({self.created:%d %b %Y})"

class Lead(models.Model):
    STAGES = [("new", "New"), ("contacted", "Contacted"), ("proposal", "Proposal"), ("won", "Won"), ("lost", "Lost")]
    name = models.CharField(max_length=120); email = models.EmailField(blank=True)
    source = models.CharField(max_length=60, default="Website")
    stage = models.CharField(max_length=12, choices=STAGES, default="new")
    value = models.PositiveIntegerField(default=0, help_text="Expected value in INR")
    created = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ["-created"]
    def __str__(self): return self.name

class Client(models.Model):
    user = models.OneToOneField(U, null=True, blank=True, on_delete=models.SET_NULL, help_text="Portal login")
    name = models.CharField(max_length=120); company = models.CharField(max_length=160, blank=True)
    email = models.EmailField(); phone = models.CharField(max_length=30, blank=True)
    def __str__(self): return self.company or self.name

class Project(models.Model):
    STATUS = [("planning", "Planning"), ("progress", "In progress"), ("review", "In review"), ("done", "Completed")]
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="projects")
    title = models.CharField(max_length=160); status = models.CharField(max_length=10, choices=STATUS, default="planning")
    progress = models.PositiveSmallIntegerField(default=0, help_text="0-100"); updated = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.title} - {self.client}"

class ProjectFile(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="files")
    title = models.CharField(max_length=160); file = models.FileField(upload_to="project_files/")
    uploaded = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.title

class Invoice(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="invoices")
    number = models.CharField(max_length=30, unique=True); amount = models.DecimalField(max_digits=10, decimal_places=2)
    file = models.FileField(upload_to="invoices/", blank=True); issued = models.DateField(); paid = models.BooleanField(default=False)
    def __str__(self): return self.number

class Ticket(models.Model):
    STATUS = [("open", "Open"), ("pending", "Pending"), ("closed", "Closed")]
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="tickets")
    subject = models.CharField(max_length=160); message = models.TextField()
    reply = models.TextField(blank=True); status = models.CharField(max_length=8, choices=STATUS, default="open")
    created = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ["-created"]
    def __str__(self): return self.subject

class BlogPost(models.Model):
    title = models.CharField(max_length=200); slug = models.SlugField(unique=True)
    body = models.TextField(); published = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ["-created"]
    def __str__(self): return self.title
